// types.ts
export type Weapon = {
    name: string;
    slug: string;
    path: string;
  };
  
  export type Category = {
    categoryName: string;
    weapons: Weapon[];
  };
  
  // If you have more complex data, you can also define nested structures
  export type WeaponsData = {
    [category: string]: Weapon[];
  };
  