const Main = () => {
  return (
    <div>
      <img src="/images/front/giantdad.jpg"></img>
    </div>
  );
};
export default Main;
