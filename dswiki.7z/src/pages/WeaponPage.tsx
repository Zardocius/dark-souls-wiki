// src/pages/WeaponPage.tsx
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { fetchWeaponByName } from "../api";
import { Weapon } from "../types"; // Import the shared Weapon type

const WeaponPage: React.FC = () => {
  const { weaponName } = useParams<{ weaponName: string | undefined }>();
  const [weapon, setWeapon] = useState<Weapon | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadWeapon = async () => {
      if (weaponName) {
        try {
          const weaponData = await fetchWeaponByName(weaponName);
          if (weaponData) {
            setWeapon(weaponData);
          } else {
            setError("Weapon data not found.");
          }
        } catch (error) {
          console.error("Error fetching weapon data:", error);
          setError("Failed to fetch weapon data.");
        } finally {
          setLoading(false);
        }
      } else {
        setError("Weapon name is undefined.");
        setLoading(false);
      }
    };

    loadWeapon();
  }, [weaponName]);

  if (loading) return <div>Loading weapon data...</div>;

  if (error) return <div>Error: {error}</div>;

  if (!weapon) return <div>No weapon data available.</div>;

  return (
    <div>
      <h2>{weapon.name}</h2>
      <p>{weapon.description}</p>
    </div>
  );
};

export default WeaponPage;
