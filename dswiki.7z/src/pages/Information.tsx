const Information = () => {
  return (
    <div>
      <p>Information</p>
    </div>
  );
};
export default Information;
