const Spells = () => {
  return (
    <div>
      <p>Spells</p>
    </div>
  );
};
export default Spells;
