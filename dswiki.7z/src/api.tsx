export const fetchWeapons = async () => {
  try {
    const response = await fetch("/database/index.json"); // Fetch index.json

    if (!response.ok) {
      const errorText = await response.text(); // Get the raw response text once
      console.error(`Error fetching data: ${response.status} ${errorText}`);
      throw new Error(`Failed to fetch weapons data: ${response.status}`);
    }

    const textData = await response.text(); // Get the response as text
    console.log("Response Data:", textData);
    // Parse the JSON data
    const data = JSON.parse(textData);

    // Return the "Weapons" array from the data, assuming the structure contains a Weapons key
    return data.Weapons;
  } catch (error) {
    console.error("Failed to parse weapons data:", error);
    throw new Error("Failed to parse weapons data");
  }
};

export const fetchWeaponByName = async (weaponName: string): Promise<any> => {
  try {
    const slug = weaponName
      .toLowerCase()
      .replace(/\s+/g, "-") // Replace spaces with hyphens
      .replace(/'/g, "-");  // Replace apostrophes with hyphens

    console.log(`Fetching data for weapon: ${slug}`);

    const response = await fetch(`/database/Weapons/${slug}.json`);

    console.log("Response status:", response.status);

    // Log the raw response text
    const text = await response.text();
    console.log("Raw Response Data:", text);

    if (!response.ok) {
      const contentType = response.headers.get("content-type");
      console.error(`Expected JSON, but received: ${contentType}`);
      throw new Error(`Weapon not found: ${response.status}`);
    }
    

    // Try parsing only if response is valid JSON
    const weaponData = JSON.parse(text);
    return weaponData;
  } catch (error) {
    console.error("Error in fetchWeaponByName:", error);
    throw error;
  }
};


