const Main = () => {
  return (
    <div>
      <p>Frontpage</p>
    </div>
  );
};
export default Main;
