const Character = () => {
  return (
    <div>
      <p>Character</p>
    </div>
  );
};
export default Character;
