const Equipment = () => {
  return (
    <div>
      <p>equipment</p>
    </div>
  );
};
export default Equipment;
